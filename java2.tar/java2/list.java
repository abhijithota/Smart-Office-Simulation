import java.util.*;
public class list
{
public static void main(String args[])
{
List set=new LinkedList();
set.add("one");
set.add("second");
set.add("3rd");
set.add(new Integer(4));
set.add(new Float(5.0F));
set.add("second");
set.remove("second");
set.add(new Integer(4));
System.out.println(set);
}
} 
