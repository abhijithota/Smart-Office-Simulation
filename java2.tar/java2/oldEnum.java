 class PlayingCard
  {
  public static final int SUIT_SPADES =0;
  public static final int SUIT_HEARTS =1;
  public static final int SUIT_CLUBS =2;
  public static final int SUIT_DIAMONDS =3;
  private int suit;
  private int rank;
  public PlayingCard(int suit,int rank)
   {
    this.suit=suit;
    this.rank=rank;
   }
  public int getSuit()
  {
    return suit;

  }
public int getRank(){return rank;};
public String getSuitName()
   {
    String name=" ";
    switch(suit)
     {
      case SUIT_SPADES:
       name="Spades";
       break;
      case SUIT_HEARTS:
        name="Hearts";
      case SUIT_CLUBS:
        name="Clubs";
       break;
      case SUIT_DIAMONDS:
         name="Diamonds";
        break;
       default:
        System.out.println("Invalid suit");
      }
   return name;
 }
}

public class oldEnum
{
 public static void main(String args[])  
  {
  	PlayingCard pc=new PlayingCard(PlayingCard.SUIT_SPADES,2);
    System.out.println("Card1 is the"+pc.getRank()+"of"+pc.getSuitName());
    PlayingCard pc1=new PlayingCard(47,2); 
    System.out.println("Card1 is the"+pc1.getRank()+"of"+pc1.getSuitName());
    }
}
