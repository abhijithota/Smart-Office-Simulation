public class Exmpscope
  {
   int i;
     public Exmpscope()
        {
          System.out.println(i);
           }
   public void m1()
    {
      int i;
      int j=7;
      this.i=i+j;
      System.out.println("i="+i+ " "+"j="+j);
      System.out.println("instance i="+this.i);
      m2(8);
     }
     public void m2(int i)
      {
       int j=20;
       this.i=i+j;
             System.out.println("i="+i+ " "+"j="+j);
            System.out.println("instance i="+this.i);
     }
 public static void main(String args[])
   {
     new Exmpscope().m1();
   }
}
