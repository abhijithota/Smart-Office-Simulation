class pushpop
{
	int arr[]=new int[10];
	int j;
	//public synchronized 
         public void push(int i)
	{
		System.out.println("Push enter "+i);
		arr[j]=i;
		j++;
		System.out.println("Push exit");
	}
//	public synchronized 
           public int pop()
	{
		System.out.println("Pop enter");
		j--;
		System.out.println("Pop exit "+arr[j]);
		return arr[j];

	}
}
class insert implements Runnable
{
	pushpop pp=new pushpop();
	public insert(pushpop p1)
	{
		pp=p1;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			pp.push(i);
			//System.out.println("push:  "+i);
		}
	}
}
class retrive implements Runnable
{
	pushpop pp=new pushpop();
	public retrive(pushpop p1)
	{
		pp=p1;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			int j=pp.pop();
			//System.out.println("pop:  "+j);
		}
	}
}
public class DemoSync
{
	public static void main(String arg[])
	{
		pushpop p1=new pushpop();
		insert in=new insert(p1);
		Thread t1=new Thread(in);
		retrive rt=new retrive(p1);
		Thread t2=new Thread(rt);
		t1.start();
		t2.start();
	}
}
