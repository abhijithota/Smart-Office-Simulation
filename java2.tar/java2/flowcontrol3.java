public class flowcontrol3
{
public static void main(String args[])
{
for(int i=0;i<10;i++)
{
System.out.println("i="+i);
for(int j=0;j<5;j++)
{
if(j==3)
continue;
System.out.println("j="+j);
}
}
}
}
