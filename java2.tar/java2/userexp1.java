class InvalidAge extends Exception
{
	public InvalidAge()
	{
		super("Age shouldn't be less than 20 or greater than 60");
	}
	/*blic String getMessage()
	{
		return "Age shouldn't be less than 20 or greater than 60";
	}*/
}
public class userexp1
{

    public void check(int age) throws InvalidAge
    {
    	if(age<20 || age>60)
				throw new InvalidAge();
			System.out.println("Age is::"+age);
	}
    	
	public static void main(String arg[])
	{
		int age=Integer.parseInt(arg[0]);
		userexp1 d1=new userexp1();
		try
		{
			d1.check(age);
		}
		catch(InvalidAge e)
		{
			System.out.println(e);
			//System.out.println("invalid age...");
		}
	}
}
