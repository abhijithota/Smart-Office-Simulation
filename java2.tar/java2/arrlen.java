public class Arrlen
{
  public void printElements(int [] list)
   {
       for(int var : list)
     {
      System.out.println(var);
     }
   }
   public static void main(String args[])
    {
       int [] a={10,20,30,40,67,89,12,34};
      Arrlen al=new Arrlen();
      al.printElements(a);
   }
}
