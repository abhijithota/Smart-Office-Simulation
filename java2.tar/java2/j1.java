import java.lang.*;
public class j1
{
String name;
int age;
int eid;
int sal;
public void show(String name,int age,int eid,int sal)
{
this.name=name;
this.age=age;
this.eid=eid;
this.sal=sal;
System.out.println(name+" "+age+" "+eid+" "+sal); 
}
public static void main(String args[])
{
j1 e=new j1();
e.show("malay",23,100,20000);
}
}
