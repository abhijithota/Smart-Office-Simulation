public class Vararr extends Object
     {
	void doShow(int...input)
	{
		for(int x: input)
		{
			System.out.println("::: "+x);
		}
	}
	public static void main(String ... args){	//SCJP eXP QUESTION
		Vararr t= new Vararr();
		t.doShow(1,2,22,3,33);
	}
}

