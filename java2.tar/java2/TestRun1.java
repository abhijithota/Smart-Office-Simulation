public class TestRun1 implements Runnable
{
	Thread th,th2;

	public TestRun1()
	{
		th = new Thread(this);
        th2 = new Thread(this);
		th.start();
        th2.start();
	
	}
	public void run()
	{
		for(int i=1;i<10;i++)
		{
			try{
                   th.sleep(2000);
				System.out.println(i);
				th2.sleep(1000);
				System.out.println(i);
			}catch(InterruptedException e)	{}
		}
	}
	public static void main(String a[])
	{
		new TestRun1();
	}

}
