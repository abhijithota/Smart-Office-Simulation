class Stacktest
{
	private int arr[]=new int[10];
	 int j;
	public synchronized void push(int i)
	{
		System.out.println("push enter");
		
		arr[j]=i;
		j++;
		this.notify();
		System.out.println("push exit "+i);
	}
	public synchronized int pop()
	{
		System.out.println("pop enter");
		j--;
		if(j<0)
		{
			try
			{
				j++;
				this.wait();
				j--;
			}
			catch(InterruptedException e){}
		}
		int value=arr[j];
		System.out.println("pop exit "+value);
		return value;
	}

}

class Produce implements Runnable
{
	private Stacktest st;
  	public Produce(Stacktest st1)
  	{
		st=st1;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			st.push(i);
			//System.out.println("data pused "+i);
		}
	}
}

class Consume implements Runnable
{
	private Stacktest st;
	int k;
	public Consume(Stacktest st1)
  	{
			st=st1;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			k=st.pop();
			//System.out.println("data poped "+k);
		}
	}
}


public class DemoStack
{
	public static void main(String ar[])
	{
		Stacktest sk=new Stacktest();
		Consume c1=new Consume(sk);
		Thread t2=new Thread(c1);
		t2.start();
		Produce p1=new Produce(sk);
		Thread t1=new Thread(p1);
		t1.start();


	}
}
