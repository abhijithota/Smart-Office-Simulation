interface interexam
{
public void sayhello();
}
public class hello implements interexam
{
public void sayhello()
{
System.out.println("hello");
}
public static void main(String args[])
{
hello e=new hello();
e.sayhello();
}
}
