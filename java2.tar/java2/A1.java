public class A1
 {
   int x=10;
   public void m1()
    {
     System.out.println("hello");
     }
 }
 class B1 extends A1
 {
    public B1()
     {
     x=20;
      }
    public void m1()
    {
     System.out.println("hi");
     }
    public static void main(String args[])
     {
       A1 a=new B1();
       System.out.println(a.x);
       a.m1();
        a=new A1();
        System.out.println(a.x);
        a.m1();
     }
}
       
