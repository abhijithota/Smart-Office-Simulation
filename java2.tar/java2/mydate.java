class mydate
{
private int day;
private int month;
private int year;
public mydate(int day,int month,int year)
{
this.day=day;
this.month=month;
this.year=year;
}
public boolean equals(Object o)
{
boolean result=false;
if((o!=null) && (o instanceof mydate))
{
mydate d=(mydate)o;
if((day==d.day) && (month==d.month) && (year==d.year))
{
result=true;
}
}
return result;
}
public int hascode()
{
return(day^month^year);
}
}
class testequal
{
public static void main(String args[])
{
mydate d1=new mydate(20,12,2000);
mydate d2=new mydate(20,12,2000);
if(d2==d1)
{
System.out.println("d1 is identical");
}
else
{
System.out.println("d2 is identical");
}
if(d1.equals(d2))
{
System.out.println("d1 equals d2");
}
else
{
System.out.println("d1 not equals d2");
}
System.out.println("set d2=d1");
d2=d1;
if(d1==d2)
{
System.out.println("d1 is identical");
}
else
{
System.out.println("d2 is identical");
}
}
}
