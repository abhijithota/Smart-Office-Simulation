class cal
{
int n=10;
}
public class calref
{
public void docall()
{
cal c=new cal();
System.out.println("before call " +c.n);
change(c);
System.out.println("after call " +c.n);
}
void change(cal c)
{
c.n=20;
System.out.println("within " +c.n);
}
public static void main(String args[])
{
new calref().docall();
}
}
