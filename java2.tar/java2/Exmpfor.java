public class Exmpfor
 {
  public static void main(String args[])
   {
      out: 
   for(int i=0;i<10;i++)
     {
      System.out.println("This is i="+i);
      for(int j=1;j<=5;j++)
       {
         if(j==3)
         {  
            continue out;
          }
         else
          {
           System.out.println("This is j="+j);
         }
      }
     }
    }
}
