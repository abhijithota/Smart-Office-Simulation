 class employee
 {
 public String name="malay";
 public double salary=10000;
 public String details()
 {
 return name+" "+salary;
 }
 }
 class manager extends employee
 {
 public double salary=12000;
 public String dept="admin";
 public String details()
 {
 return super.details()+" "+salary+" "+dept;
 }
 }
 public class supclass
 {
 public static void main(String args[])
 {
 employee e=new employee();
 System.out.println(e.details());
 manager m=new manager();
 System.out.println(m.details());
 }
 }
 
