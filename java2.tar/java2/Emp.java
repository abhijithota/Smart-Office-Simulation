import java.lang.*;
public class Emp
  {
 String Name;
    int Age;
     private int eid;
     private double sal;
          char grade;
    public Emp(String ename,int eage,int e_id,double esal,char egrade)
     {
       Name=ename;
       Age=eage;
       eid=e_id;
       sal=esal;
       grade=egrade;      
     System.out.println(Name+" "+Age+" "+eid+" "+sal+" "+grade);
    }
  }
 class Demo
   {
  public static void main(String args[])
   {
     Emp e=new Emp("Swadeen",24,100,20000.678f,'A');
    // e.Name="Sachin";
    // System.out.println(e.Name);
     }
  }
