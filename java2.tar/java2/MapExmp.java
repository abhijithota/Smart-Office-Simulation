import java.util.*;
public class MapExmp
 {
    public static void main(String args[])
      {
        Map map=new HashMap();
        map.put(1,1);
        map.put(new Integer(2),"sachin");
        map.put(3,new Integer(90));
        map.put(4,4);
        map.put(5,5);
        Set set1=map.keySet();
        Collection collection=map.values();
        Set set2=map.entrySet();
        System.out.println("keyset="+set1+"\n"+"values="+collection+"\n"+"entryset"+set2);
       }
}
        
