public class array1
{
public char[] creatarray()
{
char []s;
s=new char[26];
for(int i=0;i<26;i++)
{
s[i]=(char)('A'+i);
System.out.println(s[i]);
}
return s;
}
public static void main(String args[])
{
array1 a=new array1();
a.creatarray();
}
}
