public class point1
{
static int x;
static int y;
public point1(int x,int y)
{
this.x=x;
this.y=y;
System.out.println("x="+this.x);
System.out.println("y="+this.y);
}
public void createarr()
{
point1 []p;
p=new point1[10];
for(int i=0;i<10;i++)
{
p[i]=new point1(i,i+1);
System.out.println(p[i]);
}
}
public static void main(String args[])
{
point1 p1=new point1(x,y);
p1.createarr();
}
}
