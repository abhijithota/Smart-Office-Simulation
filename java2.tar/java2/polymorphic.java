 class employee
 {
 public String name="malay";
 public double salary=10000;
 public String details()
 {
 return name+" "+salary;
 }
 }
 class manager extends employee
 {
 public double salary=12000;
 public String dept="admin";
 public String details()
 {
 return super.details()+" "+salary+" "+dept;
 }
 }
 class clerk extends employee
 {
 public String cid="c01";
 public String details()
 {
 return name+" "+salary+" "+cid;
 }
 }
 public class polymorphic
 {
 public void show(employee e)
 {
 if(e instanceof manager)
 {
 manager m=(manager)e;
 System.out.println(m.details());
 }
 else if(e instanceof clerk)
 {
 clerk c=(clerk)e;
 System.out.println(c.details());
 }
}
 public static void main(String args[])
 {
 polymorphic p=new polymorphic();
 employee e1=new clerk();
 //System.out.println(e.details());
 employee m1=new manager();
 //System.out.println(m.details());
 p.show(m1);
 p.show(e1);
 }
 }
 
