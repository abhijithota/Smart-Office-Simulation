import java.lang.*;
import pk1.*;
public class j5
{
public static void main(String args[])
{
System.out.println("here we call the package");
System.out.println("Malay");
}
}
