class Call{
	int n=10;
}
public class Exmpcalval
    {
	public void doCall()
        {
		Call c = new Call();
		System.out.println("Before calling "+c.n);
		change(c.n);
		System.out.println("After calling "+c.n);		
	}
	void change(int n){
		n=20;
		System.out.println("Within  "+n);		
	}
	public static void main(String args[]){
		new Exmpcalval().doCall();
	}
}
