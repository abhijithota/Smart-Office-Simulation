package pk18;
  interface i2
   {
     public int add();
   }
 class G implements i2
{
public int add()
{int x=10;
return x; 
}
}	
