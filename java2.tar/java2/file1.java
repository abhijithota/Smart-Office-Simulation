import java.io.*;
public class file1
{
public static void main(String args[])
{
File f=new File("demo.txt");
try
{
InputStreamReader isr=new InputStreamReader(System.in);
BufferedReader in=new BufferedReader(isr);
PrintWriter out=new PrintWriter(f);
String s;
System.out.println("Enter the Text");
System.out.println("ctrl -d to stop");
while((s=in.readLine())!=null)
{
out.println(s);
}
in.close();
out.close();
}
catch(IOException e)
{
e.printStackTrace();
}
}
}
