public class testthis
{
public testthis()
{
this(40);
System.out.println("no parameter constructor");
}
public testthis(int x)
{
System.out.println("parameter constructor "+x);
}
public void dothis(int n)
{
System.out.println("1 int parameter constructor "+n);
}
public static void main(String args[])
{
testthis tt=new testthis();
tt.dothis(100);
}
}
