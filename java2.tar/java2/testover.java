public class testover
{
public void add(float ... input)
{
float sum=0;
for(float x:input)
{
sum=sum+x;
}
System.out.println("ov1="+sum);
}
public static void main(String args[])
{
testover to=new testover();
testover to1=new testover();
testover to2=new testover();
to.add(12.5f,13.2f);
to1.add(12.1f,13.2f,14.4f);
to2.add(11.1f,12.2f,13.3f,14.4f);
}
}
