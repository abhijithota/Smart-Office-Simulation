import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 public class Mouse implements MouseListener
  {
    JFrame f;
    JButton b1;
    JPanel p;
    JMenuBar mb;
    JMenu mi;
    JMenuItem m1;
  
public Mouse()
 {
   f=new JFrame("Mouse");
   b1=new JButton("Clicked");
    p=new JPanel();
    mb=new JMenuBar();
    mi=new JMenu("File");
    m1=new JMenuItem("New");
    p.add(b1);
    mi.add(m1);
    mb.add(mi);
    f.setJMenuBar(mb);
   f.add(p);
   f.setSize(200,200);
   f.setVisible(true);
   f.addMouseListener(this);
  }
public void mousePressed(MouseEvent me)
  {
   //if (me.getSource==b1)
  //  {
      b1.setBackground(Color.RED);
     //}
    }
public void mouseReleased(MouseEvent me2)
{
b1.setBackground(Color.WHITE);
}
public void mouseEntered(MouseEvent me2)
{
   b1.setBackground(Color.blue);
 }
public void mouseExited(MouseEvent me2)
  {
  b1.setBackground(Color.green);
  }
public void mouseClicked(MouseEvent me2)
  {
    b1.setBackground(Color.pink);
   }
public static void main(String args[])
  {
    new Mouse();
 }
}
