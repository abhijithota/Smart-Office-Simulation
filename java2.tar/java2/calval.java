class cal
{
int n=10;
}
public class calval
{
public void docall()
{
cal c=new cal();
System.out.println("before call " +c.n);
change(c.n);
System.out.println("after call " +c.n);
}
void change(int n)
{
n=20;
System.out.println("within " +n);
}
public static void main(String args[])
{
new calval().docall();
}
}
