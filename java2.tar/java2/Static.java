public class Static
{
 public static int count;
 public static int count1;
 static
  {
    count=Integer.getInteger("a.count").intValue();
   count1=Integer.getInteger("abc.count1").intValue();
  
  }
 public static void main(String args[])
  {
    
    System.out.println("Count value="+Static.count);
    System.out.println("Count value="+Static.count1);
   
   }
}
