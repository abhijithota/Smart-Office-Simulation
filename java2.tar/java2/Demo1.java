 class Employee
{
  public String Name="Sachin";
  public double salary=5000;
 }
 class Manager extends Employee
 {
   public String dept="Admin";
   public String getDetails()
    {
       return Name+ " "+salary+" "+dept;
    }
  }
class Clerk extends Employee
 {
   //public String dept="Admin";
     public String cid="c01";
   public String getDetails()
    {
       return Name+ " "+salary+" "+cid;
    }
  }
public class Demo1
{
  public void show(Employee e)
   {
     if(e instanceof Clerk)
      {
        Clerk m=(Clerk)e;
        System.out.println(m.getDetails());
      }
     }
 public static void main(String args[])
  {
    Demo1 d=new Demo1();
    //Manager m1=new Manager();
      Employee e1=new Clerk();
   d.show(e1);
  }
}
