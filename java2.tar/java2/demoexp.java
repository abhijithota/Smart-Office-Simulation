public class DemoExp
 {
   String num[]={"hello","hi","how","r u"};
   int i=10,j=0,k; 
   String s1;
   public void fun()
    {
      try
       {
         System.out.println("Name is:"+num[2]);
         k=i/j;
        System.out.println(k);
        int len=s1.length();
        }
      catch(IndexOutOfBoundsException e1)
       {
         System.out.println("Out of the range of array......");
       }
     catch(ArithmeticException e2)
       {
         System.out.println("Divided by zero....");
        }
   catch(Exception e)
    {
     System.out.println("other exception");
    }
finally
 {
   System.out.println("hello");
 }
}
public static void main(String args[])
 {
   DemoExp de=new DemoExp();
   de.fun();
 }
}  
