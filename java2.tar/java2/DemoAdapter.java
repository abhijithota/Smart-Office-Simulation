import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class DemoAdapter extends MouseMotionAdapter
{
	JFrame f1;
	JTextField tf;
	public DemoAdapter()
	{
		f1=new JFrame("Welcome to login page");
		tf=new JTextField(20);
		f1.setBackground(Color.gray);
		f1.setLayout(new FlowLayout());

		f1.add(tf);

		f1.setSize(200,200);
		f1.setVisible(true);
		f1.addMouseMotionListener(this);
	}
	public void mouseDragged(MouseEvent e){
			String s="Mouse Dragging X= "+e.getX()+" Y= "+e.getY();
			tf.setText(s);
	}
	public static void main(String ars[])
	{
		DemoAdapter tl=new DemoAdapter();
	}
}
