public class exp2
{
public static void main(String args[])
{

try
{
int z=0;
for(String arg:args)
{
z+=Integer.parseInt(arg);
System.out.println("total="+z);
}

}catch(Exception e)
{System.out.println("invalid value"+e);}
}
}
