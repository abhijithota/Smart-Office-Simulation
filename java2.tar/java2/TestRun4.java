class TRun1 implements Runnable
{
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
			try{
				System.out.println(i);
		Thread.sleep(1000);
			}catch(InterruptedException e)	{}
		}
	}
}
class TRun2 implements Runnable
{
	public void run()
	{
		for(int i=50;i<=60;i++)
		{
			try{
				System.out.println("***************"+i);
				Thread.sleep(1000);
			}catch(InterruptedException e)	{}
		}
	}
}
class TestRun4
{
	public static void main(String a[])
	{
		System.out.println("main begins...");
		TRun1 tr1= new TRun1();
		Thread th1 = new Thread(tr1);
		TRun2 tr2= new TRun2();
		Thread th2 = new Thread(tr2);
		th1.start();
		th2.start();
		try{
			th1.join();
			th2.join();
		}catch(InterruptedException eee)		{}

		System.out.println("main ends...");
	}

}
