import java.util.*;
public class set
 {
   public static void main(String args[])
    {
      List set=new ArrayList();
      set.add("one");
      set.add("second");
      set.add("3rd");
      set.add(new Integer(4));
      set.add(new Float(5.0f));
      set.add("second"); 
      set.remove("3rd");
      set.add(new Integer(4));
      System.out.println(set);
     }
  }
