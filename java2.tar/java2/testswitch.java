public class testswitch
{
public static void main(String args[])
{
int a=10;
int b=20;
System.out.println("1.area of rectangle press 1\n"+"2.area of square press 2\n"+"3.area of circle press 3");
int c=Integer.parseInt(args[0]);
switch (c)
{
case 1:
int d;
d=a*b;
System.out.println("area of rect="+d);
break;
case 2:
int e;
e=a*a;
System.out.println("area of square="+e);
break;
case 3:
int f;
f=(int)(22/7)*(a*a);
System.out.println("area of circle="+f);
break;
default:
break;
}
}
}
