public class exp3
{
public static void main(String args[])
{
int z=0;
for(String arg:args)
{
try
{
z+=Integer.parseInt(arg);
System.out.println("total="+z);

}catch(Exception e)
{System.out.println("invalid value"+e);}
}
}
}
