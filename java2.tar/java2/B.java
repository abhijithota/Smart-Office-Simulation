import java.lang.*;
 import pk1.*;
public class B
  {
   public static void main(String args[])
    {
      System.out.println("inside B.........");
      A a=new A();
      a.show();
      
     }
}
