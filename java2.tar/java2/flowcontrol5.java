public class flowcontrol5
{
public static void main(String args[])
{
outer:
for(int i=0;i<10;i++)
{
System.out.println("i="+i);
for(int j=0;j<5;j++)
{
if(j==3)
break outer;
System.out.println("j="+j);
}
}
}
}
