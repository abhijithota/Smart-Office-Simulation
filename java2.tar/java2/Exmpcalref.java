class Call{
	int n=10;
}
public class Exmpcalref{
	public void doCall(){
		Call c = new Call();
		System.out.println("Before calling "+c.n);
		change(c);
		System.out.println("After calling "+c.n);		
	}
	void change(Call c){
		c.n=20;
		System.out.println("Within  "+c.n);
	}
	public static void main(String args[]){
		new Exmpcalref().doCall();
	}
}
