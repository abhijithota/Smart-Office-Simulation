public class coverloading 
{
int a,b;
public coverloading()
{
a=10;
b=20;
System.out.println(a+","+b);
}
public coverloading(int x)
{
this();
a=x;
b=20;
System.out.println(a+","+b);
}
public coverloading(int x,int y)
{
this(x);
a=x;
b=y;
System.out.println(a+","+b);
}
public static void main(String args[])
{
coverloading c=new coverloading(13,17);
}
}
