package pk18;
  interface i2
   {
     public int add();
   }
 public class pack implements i2
{
public int add()
{int x=10;
return x; 
}
}	
