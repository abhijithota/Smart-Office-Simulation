import java.lang.*;
public class j3
{
String name;
private int age;
private int eid;
private int sal;
public void show(String name,int age,int eid,int sal)
{
this.name=name;
this.age=age;
this.eid=eid;
this.sal=sal;
System.out.println(name+" "+age+" "+eid+" "+sal); 
}
}
class Demo
{
public static void main(String args[])
{
j3 e=new j3();
e.show("malay",23,100,20000);
e.name="malay";
System.out.println(e.name);
}
}
