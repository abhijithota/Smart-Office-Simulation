import java.io.*;
public class CreateFile
{
public static void main(String[] args) 
{
File file = new File("demo2.txt");
boolean blnCreated = false;
try
{
blnCreated = file.createNewFile();
}
catch(IOException ioe)
{
System.out.println("Error while creating a new empty file :" + ioe);
}
System.out.println("Was file " + file.getPath() + " created ? : " + blnCreated);
}
}
