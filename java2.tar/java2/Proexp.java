import java.util.*;
public class Proexp
 {
  public static void main(String args[])
   {
    Properties p=System.getProperties();
    //System.out.println(p);
      p.list(System.out);
   }
 }
