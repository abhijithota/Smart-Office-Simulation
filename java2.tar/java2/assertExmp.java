public class assertExmp
{
  public static void main(String args[])
   {
     try
      {
     for(int i=10;i>-10;i--)
     {
      if(i>0)
       {
        System.out.println(i);
        }
      else
       {
      assert(i==0) : "err" ;
      System.out.println("less than 1");
       }
      }
    }
 catch(AssertionError er)
  {
    System.out.println(er.getMessage());
  }
}
}
