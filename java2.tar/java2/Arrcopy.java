public class Arrcopy
{
  int [] x={10,20,30,40,50};
  int [] y=new int [10];
//  int [] z;
 public void printelement()
  {
   //z=new  int[x.length+y.length];
   System.arraycopy(x,1,y,2,2);
//   for(int z1 : z)
  //  {
 //  System.out.println(z1);
   // }
   //System.arraycopy(y,0,z,x.length,y.length);
   for (int z2: y)
   {
   System.out.println(z2);
   }
  }
public static void main(String args[])
 {
  new Arrcopy().printelement();
 }
}
   
