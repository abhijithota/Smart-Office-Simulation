public class demo_overloading 
  {
    int a,b;
    public  demo_overloading()
      {
        a=10;
        b=20;
        System.out.println(a+ "," +b);
      }
    public   demo_overloading(int x)
      {
       this();
        a=x;
        b=15;
        System.out.println(a+","+b);
      }
    public  demo_overloading(int x,int y)
      {        this(x);
        a=x;
        b=y;
        System.out.println(a+","+b);
      }
    public static void main(String args[])
      {
        demo_overloading d=new demo_overloading(2,3);
          //demo_overloading d1=new demo_overloading(2);
        //d.demo_overloading1();
         //d.demo_overloading1(20,30);
         //d.demo_overloading1(10);
      }
   }
