import java.io.*;
public class file2
{
public static void main(String args[])
{
File file=new File("demo1.txt");
boolean bln=false;
try
{
bln=file.createNewFile();
}catch(IOException e)
{
e.printStackTrace();
}
System.out.println("path is"+file.getPath());
}
}
