public class exp1
{
public static void main(String args[])
{
int z=0;
try
{
for(String arg:args)
{
z+=Integer.parseInt(arg);
System.out.println("total="+z);
}
}catch(Exception e)
{System.out.println("invalid value"+e);}
}
}
