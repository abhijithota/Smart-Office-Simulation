public class Wrap
 {
   public static void main(String args[])
    {
      int x=10;
      Integer y=new Integer(x);
       int z=(y).intValue();
      float a=20.6f;
      Float a1=new Float(a);
      System.out.println(x+y);
      System.out.println("y="+y);
      System.out.println("z="+z);
      System.out.println("a="+a);
      System.out.println("a1="+a1);
     }
}
