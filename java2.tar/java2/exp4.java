public class exp4
{
public static void main(String args[])
{
int z=0;
for(String arg:args)
{
try
{
z+=Integer.parseInt(arg);

}catch(Exception e)
{System.out.println("invalid value"+e);}
}
System.out.println("total="+z);
}
}
