public class ThreadTester
{
 public static void main(String args[])
  {
   HelloRunner r=new HelloRunner();
   Thread t=new Thread(r);
   Thread t2=new Thread(r);
   t.start();
    System.out.println("thread 1");
   t2.start();
   System.out.println("thread 2");
  }
}
 class HelloRunner implements Runnable
 {
   int i;
   public void run()
    {
     i=0;
     while(true)
      {
       System.out.println("Hello"+i++);
       if(i==10)
        {
         break;
        }
       }
      }
   }
