public class testmain
{
static int i;
static
{
i+=10;
System.out.println(i);
}
public static void exit(0)
{
int arg=0
}
}
