interface  I1
  {
   abstract public void show();
    public void draw();
  }
public class interexmp implements I1
 {
    public void show(){System.out.println("Example of interface");}
    public void draw(){}
public static void main(String args[])
     {
      interexmp e=new interexmp();
      e.show();
      }
}
    
 
 
