import java.lang.*;
public class j2
{
String name;
int age;
int eid;
int sal;
public void show(String name,int age,int eid,int sal)
{
this.name=name;
this.age=age;
this.eid=eid;
this.sal=sal;
System.out.println(name+" "+age+" "+eid+" "+sal); 
}
}
class Demo
{
public static void main(String args[])
{
j2 e=new j2();
e.show("malay",23,100,20000);
}
}
