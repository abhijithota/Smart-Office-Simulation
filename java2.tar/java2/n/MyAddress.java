import java.net.*;
public class MyAddress
{
	public static void main(String a[])
	{
		try
		{
			InetAddress ads = InetAddress.getLocalHost();
			System.out.println("My Address is " + ads);
		}
		catch(Exception e)
		{}
	}
}