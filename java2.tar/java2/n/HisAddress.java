import java.net.*;
public class HisAddress
{
	public static void main(String a[])
	{
		try
		{
			InetAddress ads = InetAddress.getByName(a[0]);
			System.out.println("His Address is " + ads);
		}
		catch(Exception e)
		{}
	}
}