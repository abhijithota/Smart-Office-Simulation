import java.net.*;
import java.io.*;

public class Server
{
	ServerSocket srv;
	Socket soc;

	BufferedReader cin,sin;
	PrintWriter cout;

	public Server()
	{
		try
		{
			InetAddress sadd = InetAddress.getLocalHost();
			srv = new ServerSocket(1181);

			System.out.println("Server  Started on "+sadd+" ....");
			System.out.println("Waiting for client request ...");

			soc = srv.accept();

			InetAddress cadd = soc.getInetAddress();
			System.out.println("Client Request accepted from "+cadd+"\n");

			cin = new BufferedReader(new InputStreamReader(soc.getInputStream()));

			cout = new PrintWriter(new BufferedWriter(new OutputStreamWriter(soc.getOutputStream())),true);
			sin = new BufferedReader(new InputStreamReader(System.in));

			while(true)
			{
				String str = cin.readLine();
				if(str.equals("end"))
					break;

				System.out.println("Client : " + str);
				System.out.print("Server : ");
				str = sin.readLine();
				cout.println(str);
				System.out.println("Waiting for client response");
			}

			System.out.println("Session Terminated");
			srv.close();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

	public static void main(String a[])
	{
		new Server();
	}
}