public class overloading 
{
int a,b;
public void a1()
{
a=10;
b=20;
System.out.println(a+","+b);
}
public void a1(int x)
{
a=x;
b=20;
System.out.println(a+","+b);
}
public void a1(int x,int y)
{
a=x;
b=y;
System.out.println(a+","+b);
}
public static void main(String args[])
{
overloading o=new overloading();
o.a1();
o.a1(15);
o.a1(13,17);
}
}
