package pk1;
public class j4
{
public void show()
{
System.out.println("here we create a package");
System.out.println("Malay");
}
}
