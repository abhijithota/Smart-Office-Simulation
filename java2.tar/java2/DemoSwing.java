import javax.swing.*;
import java.awt.*;
public class DemoSwing
 {
   JFrame f1;
   JPanel p1;
   JButton b1,b2;
   public DemoSwing()
    {
      f1=new JFrame("Welcome");
      p1=new JPanel();
      b1=new JButton("Ok");
      b2=new JButton("Cancel");
      b1.setBackground(Color.RED);
      b2.setBackground(Color.GREEN);
      b1.setForeground(Color.GREEN);
      b2.setForeground(Color.RED);
      p1.setBackground(Color.YELLOW);
      //f1.setLayout(new FlowLayout());
      p1.add(b1);
      p1.add(b2);
      f1.add(p1);
      f1.setVisible(true);
      f1.setSize(300,300);
      f1.setLocation(200,300);
      //f1.pack();
      }
 public static void main(String args[])
 {
  new DemoSwing();
 }
}
      
