enum Suit
{
 SPADES,
 HEARTS,
 CLUBS,
 DIAMONDS;
}

class PlayingCard
{
 private Suit suit;
 private int rank;
 public PlayingCard(Suit suit,int rank)
  {
      this.suit=suit;
      this.rank=rank;
   }
  public Suit getSuit()
    {
        return suit;
     }
 public String getSuitName()
   {
    String name=" ";
    switch(suit)
     {
      case SPADES:
       name="Spades";
       break;
      case HEARTS:
        name="Hearts";
      case CLUBS:
        name="Clubs";
       break;
      case DIAMONDS:
         name="Diamonds";
        break;
      }
   return name;
}
 public int getRank(){return rank;};
}

 public class NewEnum
{
 public static void main(String args[])
  {
    PlayingCard cd=new PlayingCard(47,1);
    System.out.println("card one is the"+cd.getRank() + " of "+
            cd.getSuitName());
  }
}
