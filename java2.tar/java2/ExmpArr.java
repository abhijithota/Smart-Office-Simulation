public class ExmpArr
 {
    public static void main(String args[])
    {
      char ch[]=new char[26];
      for(int i=0;i<=26;i++)
       {
          ch[i]=(char) ('A'+i);
          System.out.println(ch[i]);
       }
     }
 }
