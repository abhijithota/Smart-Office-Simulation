class scope1
{
private int i=10;
public void m1()
{
int i=10;
int j=20;
System.out.println("i="+i+" j="+j);
this.i=i+j;
System.out.println(this.i);
m2(15);
}
void m2(int i)
{
int j=25;
this.i=i+j;
System.out.println("i="+i+" "+"j="+j);
System.out.println(this.i);
}
}
public class scope
{
public static void main(String args[]){
scope1 s=new scope1();
s.m1();
}
}
