import java.awt.*;
import javax.swing.*;
public class Frame1
  {
    JFrame f;
    JButton b1,b2;
    public Frame1()
    {
      f=new JFrame();
       b1=new JButton("OK");
       b2=new JButton("cancel");
       b1.setBackground(Color.red);
       f.setLayout(new FlowLayout());
       f.add(b1);
        f.add(b2);
       f.setSize(200,300);
       f.setBackground(Color.green);
       f.setVisible(true);
      f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
     }
   public static void main(String args[])
    {
      new Frame1();
 }
}
    
