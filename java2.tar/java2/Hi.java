import java.lang.*;
 class Hello
 {
   //main method start
   public static void main(String args[])
    {
      System.out.println("Hello");
        Hi a= new Hi();
        a.m1();
     }
  }
public class Hi
   {
     public void m1()
      {    
         System.out.println("Hi");
       }
  }
  
