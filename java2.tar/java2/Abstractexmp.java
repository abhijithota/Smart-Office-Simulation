 abstract class Absclass 
   {
    void m1()
    {
        System.out.println("this m1 impl");
    }
    void m2()
    {
        System.out.println("this m2 imple");
    }
}

public class Abstractexmp extends Absclass
{
   void m1()
    {
        System.out.println("this m1 child");
    }
    public static void main(String arg[])
    {
        Abstractexmp w=new Abstractexmp();
   //Absclass a= new Absclass ();
        //a.m1();
        w.m1();
        w.m2();
    }
}
