class userexp1 extends Exception
{
 /*public userexp1()
  {
   System.out.println("user defind exception");
  }*/
}
public class userexp
{
 public static void main(String args[])
 {
    try
     {
    int x=1;
    x=x+1;
   if(x<10)
   {
      throw new userexp1();
    } 
    System.out.println(x);
     }
catch(userexp1 ue)
   {
     System.out.println("invalid value");
}
}
}
