class TS
{
	int mark=23;
	String nm="akash";

	public String toString()
	{
		return "Name is :"+nm+" Age is : "+mark;
           }

   public static void main(String args[])
   {
	TS t= new TS();
	System.out.println(t);
   }
}
