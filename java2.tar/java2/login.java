import java.awt.*;
import javax.swing.*;
public class login
{
JFrame f;
JPanel p;
JButton b1,b2;
JTextField tx;
JPasswordField pws;
JLabel l1,l2;
public login()
{
f=new JFrame("LOGIN FIELD");
b1=new JButton("ok");
b2=new JButton("cancel");
p=new JPanel();
tx=new JTextField(20);
pws=new JPasswordField(10);
l1=new JLabel("user id");
l2=new JLabel("password");
b1.setBackground(Color.PINK);
b2.setBackground(Color.GREEN);
b1.setForeground(Color.BLACK);
b2.setForeground(Color.WHITE);
p.setBackground(Color.ORANGE);
f.setLayout(null);
l1.setBounds(10,38,150,20);
l2.setBounds(10,80,150,20);
p.setBounds(150,200,100,400);
pws.setBounds(40,60,150,70);
tx.setBounds(45,60,230,75);
b1.setBounds(50,60,220,70);
b2.setBounds(50,65,240,80);
p.add(l1);
p.add(l2);
p.add(tx);
p.add(pws);
p.add(b1);
p.add(b2);
f.add(p);

f.setVisible(true);
f.setSize(300,300);
//f.pack();
f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
}
public static void main(String args[])
{
new login();
}
}

