public class Exmpthis{

	public Exmpthis()
         {
		System.out.println("no param constructor...");
	  }
     public Exmpthis(int x)
            {
              this();
		System.out.println("no param constructor..."+x);
	}
	public void doUseThis(int n)
        {
		
		System.out.println("1 int param constructor..."+n);
	}
	public static void main(String args[]){
		//UseThis ut= new UseThis();
		Exmpthis ut1= new Exmpthis();
		ut1.doUseThis(100);
	}
}
