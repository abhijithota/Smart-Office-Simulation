class ts
{
int mark=75;
String nm="malay";
public static void main(String args[])
{
ts t=new ts();
System.out.println(t);
}
}
