public class Final
  {
    static final int x=0;
     Final()
      {
       //x=20;
       }
  
   public void m1()
    {
      //x=30;
      System.out.println(x);
    }
    public static void main(String args[])
     {
       new Final().m1();
      }
}
