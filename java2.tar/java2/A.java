package pk1;
public class A
  {
   public void show()
    {
      System.out.println("inside A.........");
     }
}
