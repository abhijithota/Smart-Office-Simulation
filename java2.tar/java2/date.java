public class date
{
int day;
String month;
int year;
public void show(int day,String month,int year)
{
this.day=day;
this.month=month;
this.year=year;
System.out.println(this.day+"-"+this.month+"-"+this.year);
}
public static void main(String args[])
{
date d=new date();
d.show(24,"may",2011);
}
}
