import java.awt.*;
import javax.swing.*;
public class gui1
{
JFrame f1;
JPanel p1;
JButton b1,b2;
public gui1()
{
f1=new JFrame("Welcome");
p1=new JPanel();
b1=new JButton("Ok");
b2=new JButton("Cancel");
b1.setBackground(Color.RED);
b2.setBackground(Color.PINK);
b1.setForeground(Color.YELLOW);
b2.setForeground(Color.GREEN);
p1.setBackground(Color.ORANGE);
p1.add(b1);
p1.add(b2);
f1.add(p1);
f1.setVisible(true);
f1.setSize(500,500);
f1.setLocation(200,300);
f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
}
public static void main(String args[])
{
new gui1();
}
}
