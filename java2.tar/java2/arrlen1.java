public class arrlen1{
public void printele(int []list){
for(int var:list)
{
System.out.println(var);
}
}
public static void main(String args[])
{
int []a={10,20,30,40,50};
arrlen1 a1=new arrlen1();
a1.printele(a);
}
}
