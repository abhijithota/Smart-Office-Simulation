class Employee
{
  public String name="Swadeen";
  public double salary=10000;
  public String getDetails()
   {
    return name+" "+salary;
   }
}
 class Manager extends Employee
  {
    //public String name="manu";
    public double salary=8000;
    public String department="Admin";
   public String getDetails()
   {
     return super.getDetails()+" "+super.salary+" "+department;
   }
 }
public class Subclass
{
 public static void main(String args[])
  {
     Employee e1=new Employee();
     System.out.println(e1.getDetails());
    Manager e=new Manager();
     System.out.println(e.getDetails());
     System.out.println(e1.getDetails());
}
}
