import java.lang.*;
public class Exmpif
  {
   public static void main(String args[])
   {
     int mark=Integer.parseInt(args[0]);
     switch(mark)
       {
        case 80:
         System.out.println("Excelent");
         break;
         case 79 :
            
          System.out.println("good");
           break;
       case 59:
         
          System.out.println("average");
          break;
        default :
       
            System.out.println("fail");
 }
 }
}
 
