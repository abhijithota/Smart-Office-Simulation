import java.io.*;
 public class WriteFile
  {
     public static void main(String args[])
      {
        File f=new File("demo1.txt");
        try
        {
          InputStreamReader isr=new InputStreamReader(System.in);
         // BufferedReader in =new BufferedReader(isr);
          PrintWriter out=new PrintWriter(f);
          String s;
          System.out.print("Enter the file text");
          System.out.println("ctrl -d to stop");
          while((s=isr.readLine())!=null)
          {
           out.println(s);
          }
          in.close();
          out.close();
         }
       catch(IOException e)
        {
         e.printStackTrace();
        }
       }
   }
