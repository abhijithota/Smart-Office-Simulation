public class testdate
{
int day;
int month;
int year;
public void show(int day,int month,int year)
{
this.day=day;
this.month=month;
this.year=year;
if(this.day >31 || this.month >12 || (this.year <=1900 || this.year >2020))
{
System.out.println("error");
}
else
{
System.out.println(this.day+"-"+this.month+"-"+this.year);
}
}
public static void main(String args[])
{
testdate d=new testdate();
int dt=Integer.parseInt(args[0]);
int m=Integer.parseInt(args[1]);
int y=Integer.parseInt(args[2]);
d.show(dt,m,y);
}
}
