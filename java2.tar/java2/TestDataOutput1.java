import java.io.*;
public class TestDataOutput1{
	public static void main(String arg[])
	{
		try{
			FileOutputStream fo=new FileOutputStream("File3.txt");
			BufferedOutputStream bs=new BufferedOutputStream(fo);
			DataOutputStream ds=new DataOutputStream(bs);
			FileInputStream fi=new FileInputStream("File3.txt");
			BufferedInputStream bi=new BufferedInputStream(fi);
			DataInputStream di=new DataInputStream(bi);

				ds.writeInt(9);				ds.writeUTF("Hello");
				ds.writeFloat(3.2f);
			    ds.close();
				int a1=di.readInt();
				System.out.println(a1);
				String s1=di.readUTF();
				System.out.println(s1);
				float f1=di.readFloat();
				System.out.println(f1);
				di.close();
		}catch(IOException e){ System.out.println(e);}
	}
}
