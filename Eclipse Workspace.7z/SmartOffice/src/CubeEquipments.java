
public class CubeEquipments {
	public Boolean turnedOn = false;
	public CubeEquipments() {
		System.out.println("Inside Cube Equipments.All Equipments Switched ON.");
		turnedOn = true;
	}

}
