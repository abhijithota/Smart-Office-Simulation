
public class Alarm {
	public boolean alarm = false;

	public Alarm() {
		System.out.println("Inside Alarm.");
		alarm =  true;
		System.out.println("Alarm Raised.");
	}

}
